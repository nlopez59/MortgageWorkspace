This folder has script and JCL initialize a WaaS stock of Image IBM z/OS 3.1  (May 2024 build)

The main script is $initVSI-Stock.bat. Its a windows batch script that runs all the 
initialization steps.  

The JCL folder has a series of JOBs to configure a basic subsystem settings like 
DB2, CICS ...

These jobs provide a minimum configuration suited to support testing with 
our sample mortgage app.  

After initialization, the ibmuser can log in to CICS and run the TranID EPSP. 

They then configure their IDE and pipeline to run DBB builds 
to test their changes in a POC.   